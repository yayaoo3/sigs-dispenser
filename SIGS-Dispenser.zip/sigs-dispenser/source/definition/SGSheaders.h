/*

    Name: Xu Xi-Ping
    Date: March 1,2017
    Last Update: March 22,2017
    Program statement: 
        In here, We define the struct and some general variables, parameters

        After that, we define some datalog format
    Edited:
        Adding uploadInfo for controlling use

*/

#include <stdint.h>
#include <pthread.h>
#include <sys/types.h>