/*

    Name: Xu Xi-Ping
    Date: April 7,2017
    Last Update: April 7,2017
    Program statement: 
        A agent for deltarpi m15-m30 

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>

#include <sys/msg.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>

#include "../protocol/SGSmodbus.h"
#include "../ipcs/SGSipcs.h"
#include "../controlling/SGScontrol.h"

#define HOT 3
#define WARM 2
#define COLD 1
#define WL_addr 211
#define SW_addr 411
#define Alert_addr 335

deviceInfo *deviceInfoPtr = NULL;

dataInfo *dataInfoPtr = NULL;

unsigned char switch_cmd[128];

int heating = 0 , watercharging = 0, compression = 0 ;

float HotConsumption = 0.0 , WarmConsumption = 0.0 , ColdConsumption = 0.0;




//Intent : Invoke modbus command and collect data
//Pre : None
//Post : On success, return 0. On error, return -1

int CollectData(deviceInfo *deviceTemp, int devfd);

int CheckSwitch();

//Intent : set up dataInfo and deviceInfo (get pointers from global parameters)
//Pre : Nothing
//Post : On success, return 0. On error, return -1 and shows the error message

int initializeInfo();

//Intent : free deviceInfoPtr, dataInforPtr and free the shared memory (get pointers from global parameters)
//Pre : Nothing
//Post : On success, return 0. On error, return -1 and shows the error messages

void releaseResource();

//Intent : shut down everything when SIGINT is catched
//Pre : Nothing
//Post : Nothing

void forceQuit(int sigNum);



int main(int argc, char *argv[])
{

    int ret = 0;
    int devfd = -1;
    struct sigaction act, oldact;
    deviceInfo *deviceTemp = NULL;
  

    //Recording program's pid

    ret = sgsInitControl("hezhong");
    if(ret < 0)
    {

        printf("thezhong aborting\n");
        return -1;

    }

    //Initialize deviceInfo and dataInfo

    ret = initializeInfo();
    if(ret < 0)
    {

        printf("hezhong aborting\n");
        return -1;

    }

    //Catch aborting signal

    act.sa_handler = (__sighandler_t)forceQuit;
    act.sa_flags = SA_ONESHOT|SA_NOMASK;
    sigaction(SIGUSR1, &act, &oldact);

    deviceTemp = deviceInfoPtr;

    //Get deviceInfoPtr which name is taida_deltarpi

    while((strcmp(deviceTemp->deviceName,"hezhong")) && (deviceTemp != NULL))
        deviceTemp = deviceTemp->next;
    
    if(deviceTemp == NULL)
    {

        printf("[%s][%s,%d] There's no data need to be written in the shm\n",argv[0],__FUNCTION__,__LINE__);
        forceQuit(-1);

    }

    //Open up the serial port

    devfd = sgsSetupModbusRTU(deviceTemp->interface,deviceTemp->protocolConfig);
    if(devfd < 0)
    {

        printf("[%s][%s,%d] Open port %s failed, bye bye.\n",argv[0],__FUNCTION__,__LINE__,deviceTemp->interface);
        forceQuit(-1);

    }
    else
    {

        printf("[%s][%s,%d] Open port %s successfully, configuration : %s , devfd = %d .\n",argv[0],__FUNCTION__,__LINE__,deviceTemp->interface,deviceTemp->protocolConfig,devfd);

    }
    
    ReadyCmd(deviceTemp);
    ReadySwitchCmd();
  
    
    
    while(1)
    {
        
        sleep(1);       
        ret = CollectData(deviceTemp, devfd);
       
    }

}

int initializeInfo()
{

    int ret = 0;
    ret = sgsInitDeviceInfo(&deviceInfoPtr);
    if(ret != 0)
    {

        printf("[%s,%d] init device conf failed ret = %d\n",__FUNCTION__,__LINE__,ret);
        return -1;

    } 

    ret = sgsInitDataInfo(deviceInfoPtr, &dataInfoPtr, 0);
    if(ret == 0) 
    {

        printf("[%s,%d] init data conf failed ret = %d\n",__FUNCTION__,__LINE__,ret);
        return -1;

    }

    return ret;

}

void releaseResource()
{

    sgsDeleteAll(deviceInfoPtr,-1);

    return ;

}

void forceQuit(int sigNum)
{

    if(deviceInfoPtr != NULL)
        releaseResource();

    printf("[taida_deltarpi][SIGUSR1] Catched (signal number %d) , forceQuitting...\n",sigNum);
    exit(0);

}

void ReadyCmd(deviceInfo *deviceTemp)
{

    dataInfo *dataTemp = deviceTemp->dataInfoPtr;
    unsigned short crcCheck = 0;

    if(dataTemp == NULL)
    {
        return;
    }
	printf("while\n");
    while(dataTemp != NULL)
    {
	//printf("first\n");
	//printf("dataTemp %s\n",dataTemp->valueName);
        dataTemp->modbusInfo.cmd[0x00] = dataTemp->modbusInfo.ID;
        dataTemp->modbusInfo.cmd[0x01] = 0x03;
        dataTemp->modbusInfo.cmd[0x02] = (dataTemp->modbusInfo.address & 0xff00) >> 8;
        dataTemp->modbusInfo.cmd[0x03] = dataTemp->modbusInfo.address & 0x00ff ;
        dataTemp->modbusInfo.cmd[0x04] = (dataTemp->modbusInfo.readLength & 0xff00) >> 8;
        dataTemp->modbusInfo.cmd[0x05] = (dataTemp->modbusInfo.readLength & 0x00ff);
        crcCheck = sgsCaculateCRC(dataTemp->modbusInfo.cmd, 6);
        dataTemp->modbusInfo.cmd[0x06] = (crcCheck & 0xff00) >> 8;
        dataTemp->modbusInfo.cmd[0x07] = crcCheck & 0x00ff;
	
        
        dataTemp = dataTemp->next;

    }
    return;

}

void ReadySwitchCmd()
{
    
    unsigned short crcCheck = 0;

    switch_cmd[0x00] = 0x01;
    switch_cmd[0x01] = 0x03;
    switch_cmd[0x02] = (411 & 0xff00) >> 8;
    switch_cmd[0x03] = 411 & 0x00ff ;
    switch_cmd[0x04] = (0x01 & 0xff00) >> 8;
    switch_cmd[0x05] = (0x01 & 0x00ff);
    crcCheck = sgsCaculateCRC(switch_cmd, 6);
    switch_cmd[0x06] = (crcCheck & 0xff00) >> 8;
    switch_cmd[0x07] = crcCheck & 0x00ff;

    return;

}

int CollectData(deviceInfo *deviceTemp, int devfd)
{

    int i = 0, ret = 0;
	int flag = 1;
	int type = 0;
    int tmp1 = 0, tmp2 = 0;
    dataLog dLog , dWaterUsingSataus;
    dataInfo *dataTemp = deviceTemp->dataInfoPtr;
	struct  timeval start;
    struct  timeval end;
    unsigned char buff[2];
    unsigned  long diff;
	float using = 0;
	
    if(deviceTemp == NULL || devfd <= 0)
    {

        printf("[%s,%d] parameters are not correct\n",__FUNCTION__,__LINE__);
        return -1;

    }

    while(dataTemp != NULL)
    {
		usleep(50);
        //Do a preprocess of detecting switch
		
        while(1)
		{
			//printf("CheckSwitch called\n");
			ret = CheckSwitch();
			
			if(ret > 0)
			{	
								
				// quickly change switch
				if(type != ret)
				{
					
					//get first start time , and only do once in CollectData fun
					if(flag){
					
					gettimeofday(&start,NULL);
					flag = 0;
					
					}
					
					printf("There's someone change type of the switch\n");
					gettimeofday(&end,NULL);
					diff = 1000000 * (end.tv_sec-start.tv_sec)+ end.tv_usec-start.tv_usec;
					printf("the difference is %ld\n",diff);
					gettimeofday(&start,NULL);
					using = diff * 41.37 / 1000000.0 ;
					printf("the using water is %lf\n",using);
					
					if(type == HOT)
						HotConsumption += using;
					
					if(type == COLD)
						ColdConsumption += using;
					
					if(type == WARM)
						WarmConsumption += using;					
					
					
				}
				//printf("tv_sec:%d\n",start.tv_sec);
				//printf("tv_usec:%d\n",start.tv_usec);
				//printf("tz_minuteswest:%d\n",start.tz_minuteswest);
				//printf("tz_dsttime:%d\n",start.tz_dsttime);
				//
				if(ret == HOT)
				{
					type = HOT;
					printf("There's someone open HOT the switch\n");					
				}
				if(ret == WARM)
				{
					type = WARM;
					printf("There's someone open WARM the switch\n");					
				}
				if(ret == COLD)
				{
					type = COLD;
					printf("There's someone open COLD the switch\n");					
				}
				
				
			}
			else
			{
				if(type == 0)
					break;
				
				//printf("There's someone close the (%d) switch\n",type);				
				gettimeofday(&end,NULL);
				diff = 1000000 * (end.tv_sec-start.tv_sec)+ end.tv_usec-start.tv_usec;
				//printf("the difference is %ld\n",diff);
				using = diff * 41.37 / 1000000.0 ;
				//printf("the using water is %lf\n",using);
				
				if(type == HOT)
					HotConsumption += using;
					
				if(type == COLD)
					ColdConsumption += using;
				
				if(type == WARM)
					WarmConsumption += using;
				
				type = 0;
				
				break;
			}
		}
	
		
		quicklySwitchInfo:
		
		// for quicklySwitchInfo Tag using
		if(dataTemp == NULL)
				return -1;
			
		//Set value switch status (Switch info  411) Heating....		
		if(dataTemp->modbusInfo.address == SW_addr)
		{			
			
			
			dLog.valueType = STRING_VALUE;
			memset(dLog.value.s,'\0',sizeof(dLog.value.s));
			
			//printf("modbusInfo.address %d\n",dataTemp->modbusInfo.address);
			//printf("valueName %s\n",dataTemp->valueName);
			
			if(!strcmp(dataTemp->valueName, "Heating"))
			{
				snprintf(dLog.value.s,(sizeof(dLog.value.s) - 1),"%d",heating);
			}
			
			else if(!strcmp(dataTemp->valueName, "Compression"))
			{
				snprintf(dLog.value.s,(sizeof(dLog.value.s) - 1),"%d",compression);
			}
			
			else if(!strcmp(dataTemp->valueName, "WaterCharge"))
			{
				snprintf(dLog.value.s,(sizeof(dLog.value.s) - 1),"%d",watercharging);
			}				
			
			else if(!strcmp(dataTemp->valueName, "HotConsumption"))
			{
				sgsReadSharedMemory(dataTemp,&dWaterUsingSataus);
				snprintf(dLog.value.s,(sizeof(dLog.value.s) - 1),"%2f",HotConsumption);	
								
				if(dWaterUsingSataus.status == 1)
					HotConsumption = 0.0;
			}
			
			else if(!strcmp(dataTemp->valueName, "WarmConsumption"))
			{
				sgsReadSharedMemory(dataTemp,&dWaterUsingSataus);
				snprintf(dLog.value.s,(sizeof(dLog.value.s) - 1),"%2f",WarmConsumption);
				
				if(dWaterUsingSataus.status == 1)
					WarmConsumption = 0.0;
			}
			
			else if(!strcmp(dataTemp->valueName, "ColdConsumption"))
			{
				sgsReadSharedMemory(dataTemp,&dWaterUsingSataus);
				snprintf(dLog.value.s,(sizeof(dLog.value.s) - 1),"%2f",ColdConsumption);
				
				if(dWaterUsingSataus.status == 1)
					ColdConsumption = 0.0;
			}
		
			sgsWriteSharedMemory(dataTemp, &dLog); 
			 
			dataTemp = dataTemp->next;
			
			goto quicklySwitchInfo;
			
		}
		
		
		
        //Retrieve data		
        ret = sgsSendModbusCommandRTU(dataTemp->modbusInfo.cmd,8,330000,dataTemp->modbusInfo.response);
        if(ret < 0)
        {

            printf("Read address %d failed\n",dataTemp->modbusInfo.address);

        }
		
		// modbus return data successfully
        if(dataTemp->modbusInfo.response[2] == 2)
        {
			memset(buff,'\0',sizeof(buff));
			
			buff[0] = dataTemp->modbusInfo.response[3];
			buff[1] = dataTemp->modbusInfo.response[4];
			
			quicklySetWaterevel:
			
			// for quicklySetWaterevel Tag using
			if(dataTemp == NULL)
				return -1;
			
			
			dLog.valueType = STRING_VALUE;
			memset(dLog.value.s,'\0',sizeof(dLog.value.s));
			
			
			//Caclate value normal status (waterlevel 211)
			if(dataTemp->modbusInfo.address == WL_addr)
			{				
			
				if(!strcmp(dataTemp->valueName, "LowWaterLevel"))
				{
					if(buff[1] & 0x01)
					{
						//printf("low water lever\n");
						strcpy(dLog.value.s , "1");					
					}
					else				
						strcpy(dLog.value.s , "0");		
				}
				
				else if(!strcmp(dataTemp->valueName, "MeanWaterLevel"))
				{
					
					if(buff[1] & 0x02)
					{
						//printf("mean water lever\n");
						strcpy(dLog.value.s , "1");	
						
					}
					else				
						strcpy(dLog.value.s , "0");	
				}
				
				else if(!strcmp(dataTemp->valueName, "HighWaterLevel"))
				{
					if(buff[1] & 0x04)
					{
						//printf("high water lever\n");		
						strcpy(dLog.value.s , "1");						
					}
					else				
						strcpy(dLog.value.s , "0");	
				}
				
				sgsWriteSharedMemory(dataTemp, &dLog);   
				
				dataTemp = dataTemp->next;
				
				goto quicklySetWaterevel;
				
			}			
            
			//Caclate value normal value
			else
			{
				
				if(dataTemp->modbusInfo.address == Alert_addr)
					snprintf(dLog.value.s,(sizeof(dLog.value.s) - 1),"%02x%02x",dataTemp->modbusInfo.response[3],dataTemp->modbusInfo.response[4]);
					
				else
				{
					tmp1 = dataTemp->modbusInfo.response[3]*256 + dataTemp->modbusInfo.response[4] ;            
					snprintf(dLog.value.s,(sizeof(dLog.value.s) - 1),"%d",tmp1);
				}

				//Store value to shared mem

				

				//memset(dLog.value.s,'\0',sizeof(dLog.value.s));
				

				//memset(dLog.sensorName,'\0',sizeof(dLog.sensorName));
				//strncpy(dLog.sensorName,dataTemp->sensorName,32);

				//memset(dLog.valueName,'\0',sizeof(dLog.valueName));
				//strncpy(dLog.valueName,dataTemp->valueName,32);
				if(dataTemp->modbusInfo.response[2] == 2)
					sgsWriteSharedMemory(dataTemp, &dLog);   
			
			}
			
			
        

        }        

	 dataTemp = dataTemp->next;
    }

}

int CheckSwitch(){
    
    unsigned char response[128];
    unsigned char status[2];
    unsigned short crcCheck = 0;
    int ret;
    int i;

    memset(response,'\0',sizeof(response));    
	memset(status,'\0',sizeof(status));
    
    ret = sgsSendModbusCommandRTU(switch_cmd,8,330000,response);    
    if(ret < 0)
    {

        printf("CheckSwitch Read address %d failed\n",411); 

    }
    
    if(ret > 0)
    {        

        for(i=0; i<ret; i++)
            printf(" %02x", *(response + i));

        printf("\n");

    }
	
    status[0] = response[3];
    status[1] = response[4];
	
	if(status[1] & 0x01)
		heating = 1 ;
	else
		heating = 0;

	if(status[1] & 0x04)
		compression = 1 ;
	else
		compression = 0;
	
	if(status[1] & 0x08)
		watercharging = 1 ;
	else
		watercharging = 0;
	
	
	
	if(status[1] & 0x80){
	    //printf("warn switch on\n");			
	    return WARM;
	}
	if(status[0] & 0x01){
	    //printf("ice switch on\n");	
	    return COLD;
	}
	if(status[1] & 0x40){
	    //printf("hot switch on\n");	
	    return HOT;
	}
	/*
	switch_cmd[0x00] = 0x01;
    switch_cmd[0x01] = 0x03;
    switch_cmd[0x02] = (411 & 0xff00) >> 8;
    switch_cmd[0x03] = 411 & 0x00ff ;
    switch_cmd[0x04] = (0x01 & 0xff00) >> 8;
    switch_cmd[0x05] = (0x01 & 0x00ff);
    crcCheck = sgsCaculateCRC(switch_cmd, 6);
    switch_cmd[0x06] = (crcCheck & 0xff00) >> 8;
    switch_cmd[0x07] = crcCheck & 0x00ff;*/
   


    return 0;
}
