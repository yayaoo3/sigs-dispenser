/*

    Name: Xu Xi-Ping
    Date: March 1,2017
    Last Update: March 8,2017
    Program statement: 
        test modbus command with giving protocol setting and ID address range

*/