/*
    Name: Xu Xi-Ping
    Date: March 1,2017
    Last Update: March 8,2017
    Program statement: 
        This is a debug program. It'll do the following task:
            1. check correctness of the configure file
            2. show the content of shared memory

*/

#include <stdio.h>
#include <stdlib.h>


int main()
{

    


}